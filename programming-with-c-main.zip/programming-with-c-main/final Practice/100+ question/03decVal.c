#include <stdio.h>
int main()
{
    // Create a program to declare two integer variables, assign them values, and display their values.
    int a = 10; // Declare and assign value to first integer variable
    int b = 20; // Declare and assign value to second integer variable
    printf("Value of a: %d\n", a);
    printf("Value of b: %d\n", b);
    // output
    /*
    Value of a: 10
    Value of b: 20
    */
    return 0;
}