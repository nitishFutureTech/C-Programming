#include <stdio.h>
int main()
{
    // show the patterns jusr using printf
    printf("1\n");
    printf("*\n");
    printf("**\n");
    printf("***\n");
    printf("****\n");
    printf("***** \n\n\n");

    printf("2\n");
    printf("*****\n");
    printf("****\n");
    printf("***\n");
    printf("**\n");
    printf("*\n\n\n");

    printf("3\n");
    printf("    *\n");
    printf("   **\n");
    printf("  ***\n");
    printf(" ****\n");
    printf("*****\n\n\n");

    // output
    /*
    1
    *
    **
    ***
  ****
  *****


  2
  *****
  ****
  ***
  **
  *


  3
  *
  **
  ***
  ****
  *****

  */
    return 0;
}