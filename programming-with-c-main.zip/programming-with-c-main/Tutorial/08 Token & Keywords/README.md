# C Tokens 

In **C programming**, the **smallest individual unit** in a program is called a **Token**.  
A C program is made up of different tokens, and the compiler breaks the program into these tokens for processing.

---

## 🔹 Types of Tokens in C
C tokens are divided into the following categories:

1. **Keywords**  
2. **Identifiers**  
3. **Constants**  
4. **Strings**  
5. **Operators**  
6. **Punctuation / Special Symbols**

---

## 1. Keywords
- Keywords are **reserved words** in C.  
- They have **predefined meaning** and cannot be used as identifiers (variable, function names, etc).  

### Examples:
```
int, float, char, if, else, while, for, return, break, continue, void
```

### Notes:
- C has **32 standard keywords** (in C89 standard).  
- Example usage:  
```c
int number;
if(number > 0) {
    return 1;
}
```

---

## 2. Identifiers
- Identifiers are **names given by the programmer** to elements like variables, functions, arrays, etc.
- They must follow certain rules.

### Rules for Identifiers:
- Must begin with a **letter (a-z, A-Z)** or **underscore (_)**.  
- Can contain letters, digits (0-9), and underscore.  
- **Case-sensitive** (`Total` and `total` are different).  
- Cannot use **keywords** as identifiers.  

### Examples:
```c
int age;
float totalMarks;
char _name[20];
```

---

## 3. Constants
Constants are **fixed values** that do not change during program execution.

### Types of Constants:
1. **Integer Constants** – e.g., `10`, `-25`, `0`  
2. **Floating-point Constants** – e.g., `3.14`, `-0.001`, `2.5e3`  
3. **Character Constants** – enclosed in single quotes, e.g., `'A'`, `'5'`, `'
'`  
4. **Enumeration Constants** – defined using `enum` keyword.  

### Example:
```c
#define PI 3.14159   // symbolic constant
const int maxScore = 100;
```

---

## 4. Strings
- A **string constant** is a sequence of characters enclosed in **double quotes**.  
- The compiler automatically adds a **null character (' ')** at the end.

### Example:
```c
char name[] = "OpenAI";
printf("Hello, World!");
```

---

## 5. Operators
Operators are symbols that perform operations on variables and values.

### Types of Operators:
1. **Arithmetic Operators** → `+`, `-`, `*`, `/`, `%`  
2. **Relational Operators** → `==`, `!=`, `>`, `<`, `>=`, `<=`  
3. **Logical Operators** → `&&`, `||`, `!`  
4. **Assignment Operators** → `=`, `+=`, `-=`, `*=`, `/=`, `%=`  
5. **Increment/Decrement Operators** → `++`, `--`  
6. **Bitwise Operators** → `&`, `|`, `^`, `<<`, `>>`, `~`  
7. **Conditional (Ternary) Operator** → `? :`  
8. **Comma Operator** → `,`  
9. **sizeof Operator** → `sizeof()`  

### Example:
```c
int a = 10, b = 20;
int sum = a + b;        // Arithmetic
if(a > b)               // Relational
    printf("a is bigger");
```

---

## 6. Punctuation / Special Symbols
Special characters in C are used as **separators, grouping symbols, and operators**.

### Common Symbols:
- **Braces `{ }`** → Define blocks of code.  
- **Parentheses `( )`** → Used in functions and expressions.  
- **Brackets `[ ]`** → Used for arrays.  
- **Semicolon `;`** → Terminates statements.  
- **Comma `,`** → Separates values.  
- **Period `.`** → Access structure/union members.  
- **Arrow `->`** → Access structure pointer members.  
- **# (Hash)** → Preprocessor directives.  

### Example:
```c
#include <stdio.h>
int main() {
    int arr[3] = {1, 2, 3};
    printf("%d", arr[0]);   // Access array element
    return 0;
}
```

---

## 🔹 Summary
- A **C Token** is the **basic building block** of a C program.  
- Categories: **Keywords, Identifiers, Constants, Strings, Operators, and Special Symbols**.  
- The compiler scans a program and breaks it into these tokens before execution.

---

# Keywords in C – Complete Explanation

## 🔹 What is a Keyword?
- A **Keyword** in C is a **reserved word** predefined by the compiler.  
- Keywords have **special meaning** and are used to perform specific operations or define the structure of a program.  
- They **cannot be used** as variable names, function names, or identifiers.  

### Example:
```c
int age = 20;   // 'int' is a keyword
if(age > 18) {  // 'if' is a keyword
    printf("Adult");
}
```

---

## 🔹 Advantages of Keywords
1. **Standardization** – Keywords ensure a uniform way to write programs across different systems.  
2. **Readability** – Code becomes easier to read and understand.  
3. **Efficiency** – The compiler already knows the meaning of keywords, so it can process them quickly.  
4. **Structure** – Keywords define the flow and structure of the program (loops, conditions, data types, etc.).  
5. **Portability** – Since keywords are the same across compilers, programs are portable.  

---

## 🔹 Keywords in Different C Standards

### ✅ C89 / ANSI C (32 Keywords)
```
auto       double     int        struct
break      else       long       switch
case       enum       register   typedef
char       extern     return     union
const      float      short      unsigned
continue   for        signed     void
default    goto       sizeof     volatile
do         if         static     while
```

---

### ✅ Added in C99 (5 Keywords → Total 37)
```
_Bool      inline     restrict     _Complex     _Imaginary
```

---

### ✅ Added in C11 (7 Keywords → Total 44)
```
_Alignas   _Alignof   _Atomic      _Generic
_Noreturn  _Static_assert   _Thread_local
```

---

### ✅ Added in C23 (~14 more → Around 58 Keywords Total)
```
constexpr   char8_t    typeof      typeof_unqual
true        false      nullptr     bitand
bitor       compl      not         not_eq
or          or_eq      xor         xor_eq
```

---

## 🔹 Approximate Total
- **C89 / C90** → 32  
- **C99** → 37  
- **C11** → 44  
- **C23 (latest)** → ~58 (depends on compiler support)  

---

## 🔹 Example Program Using Keywords
```c
#include <stdio.h>
#include <stdbool.h>   // enables true/false in C99+

int main() {
    _Bool isAdult = true;    // keyword _Bool
    int age = 20;            // keyword int
    if(isAdult && age >= 18) {   // keyword if
        printf("Adult\n");
    } else {
        printf("Minor\n");
    }
    return 0;   // keyword return
}
```

---

## 🔹 Summary
- **Keywords** are special reserved words in C.  
- They **cannot** be used as identifiers.  
- They provide **structure, readability, efficiency, and portability**.  
- Classic C started with **32 keywords**, and modern C (C23) has **about 58**.  

---

